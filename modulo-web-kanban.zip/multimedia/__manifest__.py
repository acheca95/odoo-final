{
    'name': 'multimedia',
    'summary': 'modulo de cartelera',
    'author': 'checa',
    'version': '1.0',
    'depends': ['base']
}

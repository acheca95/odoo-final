{
    'name': 'cineyseries',
    'summary': 'modulo de cine y series',
    'description':"""Modulo catalogo para cines y series""",
    'author': 'checa',
    'version': '1.0',
    'depends': ['base','multimedia'],
    'data': ['views/series.xml','views/cine.xml','views/menu.xml']
}
